Install-Module -Name Az.Accounts -Force -Scope CurrentUser
Install-Module -Name Az.KeyVault -Force -Scope CurrentUser
