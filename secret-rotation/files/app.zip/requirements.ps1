@{
    Modules = @(
        'Az.Accounts'
        'Az.KeyVault'
    )
}
